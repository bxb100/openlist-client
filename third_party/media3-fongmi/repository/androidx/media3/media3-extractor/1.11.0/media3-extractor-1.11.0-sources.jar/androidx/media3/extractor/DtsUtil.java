/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.SOURCE;

import androidx.annotation.IntDef;
import androidx.annotation.Nullable;
import androidx.annotation.StringDef;
import androidx.media3.common.C;
import androidx.media3.common.DrmInitData;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.ParserException;
import androidx.media3.common.util.ParsableBitArray;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import java.io.IOException;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/** Utility methods for parsing DTS frames. */
@UnstableApi
public final class DtsUtil {

  /** Information parsed from a DTS frame header. */
  public static final class DtsHeader {
    /** The mime type of the DTS bitstream. */
    @Nullable public final @DtsAudioMimeType String mimeType;

    /** The audio sampling rate in Hertz, or {@link C#RATE_UNSET_INT} if unknown. */
    public final int sampleRate;

    /** The number of channels, or {@link C#LENGTH_UNSET} if unknown. */
    public final int channelCount;

    /** The size of the DTS frame (compressed), in bytes. */
    public final int frameSize;

    /** The duration of the DTS frame in microseconds, or {@link C#TIME_UNSET} if unknown. */
    public final long frameDurationUs;

    /** The bitrate of compressed stream. */
    public final int bitrate;

    /** The codec marker of the DTS bitstream, or null if unknown. */
    @Nullable public final String codecs;

    private DtsHeader(
        @Nullable String mimeType,
        int channelCount,
        int sampleRate,
        int frameSize,
        long frameDurationUs,
        int bitrate,
        @Nullable String codecs) {
      this.mimeType = mimeType;
      this.channelCount = channelCount;
      this.sampleRate = sampleRate;
      this.frameSize = frameSize;
      this.frameDurationUs = frameDurationUs;
      this.bitrate = bitrate;
      this.codecs = codecs;
    }

    /** Returns a copy with {@link #codecs} replaced. */
    public DtsHeader withCodecs(@Nullable String codecs) {
      if (Objects.equals(this.codecs, codecs)) {
        return this;
      }
      return new DtsHeader(
          mimeType, channelCount, sampleRate, frameSize, frameDurationUs, bitrate, codecs);
    }
  }

  /**
   * The possible MIME types for DTS that can be used.
   *
   * <p>One of:
   *
   * <ul>
   *   <li>{@link MimeTypes#AUDIO_DTS}
   *   <li>{@link MimeTypes#AUDIO_DTS_EXPRESS}
   *   <li>{@link MimeTypes#AUDIO_DTS_HD}
   *   <li>{@link MimeTypes#AUDIO_DTS_HD_MA}
   *   <li>{@link MimeTypes#AUDIO_MEDIA3_DTS_HD_MA_CORELESS}
   *   <li>{@link MimeTypes#AUDIO_DTS_UHD_P2}
   * </ul>
   */
  @Documented
  @Retention(SOURCE)
  @Target(TYPE_USE)
  @StringDef({
    MimeTypes.AUDIO_DTS,
    MimeTypes.AUDIO_DTS_EXPRESS,
    MimeTypes.AUDIO_DTS_HD,
    MimeTypes.AUDIO_DTS_HD_MA,
    MimeTypes.AUDIO_MEDIA3_DTS_HD_MA_CORELESS,
    MimeTypes.AUDIO_DTS_UHD_P2
  })
  public @interface DtsAudioMimeType {}

  /**
   * Frame types for a DTS stream.
   *
   * <p>One of:
   *
   * <ul>
   *   <li>{@link #FRAME_TYPE_UNKNOWN}
   *   <li>{@link #FRAME_TYPE_CORE}
   *   <li>{@link #FRAME_TYPE_EXTENSION_SUBSTREAM}
   *   <li>{@link #FRAME_TYPE_UHD_SYNC}
   *   <li>{@link #FRAME_TYPE_UHD_NON_SYNC}
   * </ul>
   */
  @Documented
  @Retention(SOURCE)
  @Target(TYPE_USE)
  @IntDef({
    FRAME_TYPE_UNKNOWN,
    FRAME_TYPE_CORE,
    FRAME_TYPE_EXTENSION_SUBSTREAM,
    FRAME_TYPE_UHD_SYNC,
    FRAME_TYPE_UHD_NON_SYNC
  })
  public @interface FrameType {}

  /** Represents a DTS frame for which type is unknown. */
  public static final int FRAME_TYPE_UNKNOWN = 0;

  /** Represents a DTS core frame. */
  public static final int FRAME_TYPE_CORE = 1;

  /** Represents a DTS extension substream frame. */
  public static final int FRAME_TYPE_EXTENSION_SUBSTREAM = 2;

  /** Represents a DTS UHD sync frame. */
  public static final int FRAME_TYPE_UHD_SYNC = 3;

  /** Represents a DTS UHD non-sync frame. */
  public static final int FRAME_TYPE_UHD_NON_SYNC = 4;

  /**
   * Maximum rate for a DTS audio stream, in bytes per second.
   *
   * <p>DTS allows an 'open' bitrate, but we assume the maximum listed value: 1536 kbit/s.
   */
  public static final int DTS_MAX_RATE_BYTES_PER_SECOND = 1536 * 1000 / 8;

  /** Maximum rate for a DTS-HD audio stream, in bytes per second. */
  public static final int DTS_HD_MAX_RATE_BYTES_PER_SECOND = 18000 * 1000 / 8;

  /** Maximum bit-rate for a DTS Express audio stream, in bits per second. */
  public static final int DTS_EXPRESS_MAX_RATE_BITS_PER_SECOND = 768000;

  /** Maximum DTS-HD MA XLL payload bytes to scan for DTS:X markers. */
  public static final int XLL_X_SCAN_MAX_BYTES = 256 * 1024;

  /**
   * DTS Core Syncword (in different Endianness). See ETSI TS 102 114 V1.6.1 (2019-08), Section 5.3.
   */
  private static final int SYNC_VALUE_BE = 0x7FFE8001;

  private static final int SYNC_VALUE_14B_BE = 0x1FFFE800;
  private static final int SYNC_VALUE_LE = 0xFE7F0180;
  private static final int SYNC_VALUE_14B_LE = 0xFF1F00E8;

  /**
   * DTS Extension Substream Syncword (in different Endianness). See ETSI TS 102 114 (V1.6.1)
   * Section 7.4.1.
   */
  private static final int SYNC_VALUE_EXTSS_BE = 0x64582025;

  private static final int SYNC_VALUE_EXTSS_LE = 0x25205864;

  /**
   * DTS UHD FTOC Sync words (in different Endianness). See ETSI TS 103 491 (V1.2.1) Section
   * 6.4.4.1.
   */
  private static final int SYNC_VALUE_UHD_FTOC_SYNC_BE = 0x40411BF2;

  private static final int SYNC_VALUE_UHD_FTOC_SYNC_LE = 0xF21B4140;
  private static final int SYNC_VALUE_UHD_FTOC_NONSYNC_BE = 0x71C442E8;
  private static final int SYNC_VALUE_UHD_FTOC_NONSYNC_LE = 0xE842C471;
  private static final int DCA_SYNCWORD_XLL_X = 0x02000850;
  private static final int DCA_SYNCWORD_XLL_X_IMAX_SHIFTED = 0xF14000D0 >>> 1;

  private static final byte FIRST_BYTE_BE = (byte) (SYNC_VALUE_BE >>> 24);
  private static final byte FIRST_BYTE_14B_BE = (byte) (SYNC_VALUE_14B_BE >>> 24);
  private static final byte FIRST_BYTE_LE = (byte) (SYNC_VALUE_LE >>> 24);
  private static final byte FIRST_BYTE_14B_LE = (byte) (SYNC_VALUE_14B_LE >>> 24);
  private static final byte FIRST_BYTE_EXTSS_BE = (byte) (SYNC_VALUE_EXTSS_BE >>> 24);
  private static final byte FIRST_BYTE_EXTSS_LE = (byte) (SYNC_VALUE_EXTSS_LE >>> 24);
  private static final byte FIRST_BYTE_UHD_FTOC_SYNC_BE =
      (byte) (SYNC_VALUE_UHD_FTOC_SYNC_BE >>> 24);
  private static final byte FIRST_BYTE_UHD_FTOC_SYNC_LE =
      (byte) (SYNC_VALUE_UHD_FTOC_SYNC_LE >>> 24);
  private static final byte FIRST_BYTE_UHD_FTOC_NONSYNC_BE =
      (byte) (SYNC_VALUE_UHD_FTOC_NONSYNC_BE >>> 24);
  private static final byte FIRST_BYTE_UHD_FTOC_NONSYNC_LE =
      (byte) (SYNC_VALUE_UHD_FTOC_NONSYNC_LE >>> 24);

  /** Maps AMODE to the number of channels. See ETSI TS 102 114 table 5-4. */
  private static final int[] CHANNELS_BY_AMODE =
      new int[] {1, 2, 2, 2, 2, 3, 3, 4, 4, 5, 6, 6, 6, 7, 8, 8};

  /** Maps SFREQ to the sampling frequency in Hz. See ETSI TS 102 114 table 5-5. */
  private static final int[] SAMPLE_RATE_BY_SFREQ =
      new int[] {
        -1, 8_000, 16_000, 32_000, -1, -1, 11_025, 22_050, 44_100, -1, -1, 12_000, 24_000, 48_000,
        -1, -1
      };

  /** Maps RATE to 2 * bitrate in kbit/s. See ETSI TS 102 114 table 5-7. */
  private static final int[] TWICE_BITRATE_KBPS_BY_RATE =
      new int[] {
        64, 112, 128, 192, 224, 256, 384, 448, 512, 640, 768, 896, 1_024, 1_152, 1_280, 1_536,
        1_920, 2_048, 2_304, 2_560, 2_688, 2_816, 2_823, 2_944, 3_072, 3_840, 4_096, 6_144, 7_680
      };

  /**
   * Maps MaxSampleRate index to sampling frequency in Hz. See ETSI TS 102 114 V1.6.1 (2019-08)
   * Table 7-9.
   */
  private static final int[] SAMPLE_RATE_BY_INDEX =
      new int[] {
        8_000, 16_000, 32_000, 64_000, 128_000, 22_050, 44_100, 88_200, 176_400, 352_800, 12_000,
        24_000, 48_000, 96_000, 192_000, 384_000
      };

  /**
   * Payload length table for DTS UHD FTOC messages. See ETSI TS 103 491 V1.2.1 (2019-05), Section
   * 6.4.3.
   */
  private static final int[] UHD_FTOC_PAYLOAD_LENGTH_TABLE = new int[] {5, 8, 10, 12};

  /** Metadata chunk size length table for DTS UHD. See ETSI TS 103 491 V1.2.1, Table 6-20. */
  private static final int[] UHD_METADATA_CHUNK_SIZE_LENGTH_TABLE = new int[] {6, 9, 12, 15};

  /** Audio chunk ID length table for DTS UHD. See ETSI TS 103 491 V1.2.1, Section 6.4.14.4. */
  private static final int[] UHD_AUDIO_CHUNK_ID_LENGTH_TABLE = new int[] {2, 4, 6, 8};

  /** Audio chunk size length table for DTS UHD. See ETSI TS 103 491 V1.2.1, Section 6.4.14.4. */
  private static final int[] UHD_AUDIO_CHUNK_SIZE_LENGTH_TABLE = new int[] {9, 11, 13, 16};

  /** Header size length table for DTS UHD. See ETSI TS 103 491 V1.2.1 (2019-05), Section 6.4.3. */
  private static final int[] UHD_HEADER_SIZE_LENGTH_TABLE = new int[] {5, 8, 10, 12};

  /**
   * Returns whether {@code mimeType} is {@link MimeTypes#AUDIO_DTS} or {@link
   * MimeTypes#AUDIO_DTS_HD}.
   */
  public static boolean isDtsBaseAudioMimeType(@Nullable String mimeType) {
    return Objects.equals(mimeType, MimeTypes.AUDIO_DTS)
        || Objects.equals(mimeType, MimeTypes.AUDIO_DTS_HD);
  }

  /** Returns whether {@code mimeType} identifies a DTS-HD MA bitstream. */
  public static boolean isDtsHdMaAudioMimeType(@Nullable String mimeType) {
    return Objects.equals(mimeType, MimeTypes.AUDIO_DTS_HD_MA)
        || Objects.equals(mimeType, MimeTypes.AUDIO_MEDIA3_DTS_HD_MA_CORELESS);
  }

  /** Returns the DTS:X codec marker found in {@code data}, or null if none is found. */
  @Nullable
  public static String getDtsXCodecs(byte[] data, int offset, int length) {
    int word = 0;
    int end = Math.min(data.length, offset + length);
    for (int i = offset; i < end; i++) {
      word = (word << 8) | (data[i] & 0xFF);
      @Nullable String codecs = getDtsXCodecs(word);
      if (codecs != null) {
        return codecs;
      }
    }
    return null;
  }

  /** Returns the DTS:X codec marker for a rolling 32-bit sync word, or null if it is not DTS:X. */
  @Nullable
  public static String getDtsXCodecs(int word) {
    if (word == DCA_SYNCWORD_XLL_X) {
      return MimeTypes.CODEC_DTS_HD_MA_X;
    }
    return (word >>> 1) == DCA_SYNCWORD_XLL_X_IMAX_SHIFTED
        ? MimeTypes.CODEC_DTS_HD_MA_X_IMAX
        : null;
  }

  /**
   * Returns the {@link FrameType} if {@code word} is a DTS sync word, otherwise {@link
   * #FRAME_TYPE_UNKNOWN}.
   */
  public static @FrameType int getFrameType(int word) {
    if (word == SYNC_VALUE_BE
        || word == SYNC_VALUE_LE
        || word == SYNC_VALUE_14B_BE
        || word == SYNC_VALUE_14B_LE) {
      return FRAME_TYPE_CORE;
    } else if (word == SYNC_VALUE_EXTSS_BE || word == SYNC_VALUE_EXTSS_LE) {
      return FRAME_TYPE_EXTENSION_SUBSTREAM;
    } else if (word == SYNC_VALUE_UHD_FTOC_SYNC_BE || word == SYNC_VALUE_UHD_FTOC_SYNC_LE) {
      return FRAME_TYPE_UHD_SYNC;
    } else if (word == SYNC_VALUE_UHD_FTOC_NONSYNC_BE || word == SYNC_VALUE_UHD_FTOC_NONSYNC_LE) {
      return FRAME_TYPE_UHD_NON_SYNC;
    }
    return FRAME_TYPE_UNKNOWN;
  }

  /**
   * Returns the DTS format given {@code data} containing the DTS Core frame according to ETSI TS
   * 102 114 V1.6.1 (2019-08) subsections 5.3/5.4.
   *
   * @param frame The DTS Core frame to parse.
   * @param trackId The track identifier to set on the format.
   * @param language The language to set on the format.
   * @param roleFlags The role flags to set on the format.
   * @param containerMimeType The MIME type of the container to set on the format.
   * @param drmInitData {@link DrmInitData} to be included in the format.
   * @return The DTS format parsed from data in the header.
   */
  public static Format parseDtsFormat(
      byte[] frame,
      @Nullable String trackId,
      @Nullable String language,
      @C.RoleFlags int roleFlags,
      String containerMimeType,
      @Nullable DrmInitData drmInitData) {
    ParsableBitArray frameBits = getNormalizedFrame(frame);
    frameBits.skipBits(32 + 1 + 5 + 1 + 7 + 14); // SYNC, FTYPE, SHORT, CPF, NBLKS, FSIZE
    int amode = frameBits.readBits(6);
    int channelCount = CHANNELS_BY_AMODE[amode];
    int sfreq = frameBits.readBits(4);
    int sampleRate = SAMPLE_RATE_BY_SFREQ[sfreq];
    int rate = frameBits.readBits(5);
    int bitrate =
        rate >= TWICE_BITRATE_KBPS_BY_RATE.length
            ? Format.NO_VALUE
            : TWICE_BITRATE_KBPS_BY_RATE[rate] * 1000 / 2;
    frameBits.skipBits(10); // MIX, DYNF, TIMEF, AUXF, HDCD, EXT_AUDIO_ID, EXT_AUDIO, ASPF
    channelCount += frameBits.readBits(2) > 0 ? 1 : 0; // LFF
    return new Format.Builder()
        .setId(trackId)
        .setContainerMimeType(containerMimeType)
        .setSampleMimeType(MimeTypes.AUDIO_DTS)
        .setAverageBitrate(bitrate)
        .setChannelCount(channelCount)
        .setSampleRate(sampleRate)
        .setDrmInitData(drmInitData)
        .setLanguage(language)
        .setRoleFlags(roleFlags)
        .build();
  }

  /**
   * Returns the number of audio samples represented by the given DTS Core frame.
   *
   * @param data The frame to parse.
   * @return The number of audio samples represented by the frame.
   */
  public static int parseDtsAudioSampleCount(byte[] data) {
    int nblks;
    switch (data[0]) {
      case FIRST_BYTE_LE:
        nblks = ((data[5] & 0x01) << 6) | ((data[4] & 0xFC) >> 2);
        break;
      case FIRST_BYTE_14B_LE:
        nblks = ((data[4] & 0x07) << 4) | ((data[7] & 0x3C) >> 2);
        break;
      case FIRST_BYTE_14B_BE:
        nblks = ((data[5] & 0x07) << 4) | ((data[6] & 0x3C) >> 2);
        break;
      default:
        // We blindly assume FIRST_BYTE_BE if none of the others match.
        nblks = ((data[4] & 0x01) << 6) | ((data[5] & 0xFC) >> 2);
    }
    return (nblks + 1) * 32;
  }

  /**
   * Like {@link #parseDtsAudioSampleCount(byte[])} but reads from a {@link ByteBuffer}. The
   * buffer's position is not modified.
   *
   * @param buffer The {@link ByteBuffer} from which to read.
   * @return The number of audio samples represented by the syncframe.
   */
  public static int parseDtsAudioSampleCount(ByteBuffer buffer) {
    if ((buffer.getInt(0) == SYNC_VALUE_UHD_FTOC_SYNC_LE)
        || (buffer.getInt(0) == SYNC_VALUE_UHD_FTOC_NONSYNC_LE)) {
      // Check for DTS:X Profile 2 sync or non sync word and return 1024 if found. This is the only
      // audio sample count that is used by DTS:X Streaming Encoder.
      return 1024;
    } else if (buffer.getInt(0) == SYNC_VALUE_EXTSS_LE) {
      // Check for DTS Express sync word and return 4096 if found. This is the only audio sample
      // count that is used by DTS Streaming Encoder.
      return 4096;
    }

    // See ETSI TS 102 114 subsection 5.4.1.
    int position = buffer.position();
    int nblks;
    switch (buffer.get(position)) {
      case FIRST_BYTE_LE:
        nblks = ((buffer.get(position + 5) & 0x01) << 6) | ((buffer.get(position + 4) & 0xFC) >> 2);
        break;
      case FIRST_BYTE_14B_LE:
        nblks = ((buffer.get(position + 4) & 0x07) << 4) | ((buffer.get(position + 7) & 0x3C) >> 2);
        break;
      case FIRST_BYTE_14B_BE:
        nblks = ((buffer.get(position + 5) & 0x07) << 4) | ((buffer.get(position + 6) & 0x3C) >> 2);
        break;
      default:
        // We blindly assume FIRST_BYTE_BE if none of the others match.
        nblks = ((buffer.get(position + 4) & 0x01) << 6) | ((buffer.get(position + 5) & 0xFC) >> 2);
    }
    return (nblks + 1) * 32;
  }

  /**
   * Returns the size in bytes of the given DTS Core frame.
   *
   * @param data The frame to parse.
   * @return The frame's size in bytes.
   */
  public static int getDtsFrameSize(byte[] data) {
    int fsize;
    boolean uses14BitPerWord = false;
    switch (data[0]) {
      case FIRST_BYTE_14B_BE:
        fsize = (((data[6] & 0x03) << 12) | ((data[7] & 0xFF) << 4) | ((data[8] & 0x3C) >> 2)) + 1;
        uses14BitPerWord = true;
        break;
      case FIRST_BYTE_LE:
        fsize = (((data[4] & 0x03) << 12) | ((data[7] & 0xFF) << 4) | ((data[6] & 0xF0) >> 4)) + 1;
        break;
      case FIRST_BYTE_14B_LE:
        fsize = (((data[7] & 0x03) << 12) | ((data[6] & 0xFF) << 4) | ((data[9] & 0x3C) >> 2)) + 1;
        uses14BitPerWord = true;
        break;
      default:
        // We blindly assume FIRST_BYTE_BE if none of the others match.
        fsize = (((data[5] & 0x03) << 12) | ((data[6] & 0xFF) << 4) | ((data[7] & 0xF0) >> 4)) + 1;
    }

    if (!uses14BitPerWord) {
      return fsize;
    }
    // A 14-bit stream stores each 14-bit word in a 16-bit container. Convert the unpacked byte size
    // to a whole number of 14-bit words before converting those words to physical bytes. For
    // example, DTS-CD frames with FSIZE+1 equal to 3585 have their next sync word after 2048 stored
    // words, or 4096 bytes.
    return (fsize * C.BITS_PER_BYTE / 14) * 2;
  }

  /**
   * Parses the {@link DtsHeader} data from the extension substream header of a DTS-HD frame
   * according to ETSI TS 102 114 V1.6.1 (2019-08), Section 7.5.2.
   *
   * @param header The DTS-HD extension substream header to parse.
   * @return The {@link DtsHeader} data extracted from the header.
   */
  public static DtsHeader parseDtsHdHeader(byte[] header) throws ParserException {
    ParsableBitArray headerBits = getNormalizedFrame(header);
    headerBits.skipBits(32 + 8); // SYNCEXTSSH, UserDefinedBits

    int extensionSubstreamIndex = headerBits.readBits(2); // nExtSSIndex
    int headerSizeInBits; // nuBits4Header
    int extensionSubstreamFrameSizeBits; // nuBits4ExSSFsize
    if (!headerBits.readBit()) { // bHeaderSizeType
      headerSizeInBits = 8;
      extensionSubstreamFrameSizeBits = 16;
    } else {
      headerSizeInBits = 12;
      extensionSubstreamFrameSizeBits = 20;
    }
    headerBits.skipBits(headerSizeInBits); // nuExtSSHeaderSize
    int extensionSubstreamFrameSize =
        headerBits.readBits(extensionSubstreamFrameSizeBits) + 1; // nuExtSSFsize

    int assetsCount; // nuNumAssets
    int referenceClockCode; // nuRefClockCode
    int extensionSubstreamFrameDurationCode; // nuExSSFrameDurationCode
    boolean enableMixMetadata = false; // bMixMetadataEnbl
    int[] mixerOutChannels = null;

    boolean staticFieldsPresent = headerBits.readBit(); // bStaticFieldsPresent
    if (staticFieldsPresent) {
      referenceClockCode = headerBits.readBits(2);
      extensionSubstreamFrameDurationCode = 512 * (headerBits.readBits(3) + 1);

      if (headerBits.readBit()) { // bTimeStampFlag
        headerBits.skipBits(32 + 4); // nuTimeStamp, nLSB
      }

      int audioPresentationsCount = headerBits.readBits(3) + 1; // nuNumAudioPresnt
      assetsCount = headerBits.readBits(3) + 1;
      if (audioPresentationsCount != 1 || assetsCount != 1) {
        throw ParserException.createForUnsupportedContainerFeature(
            /* message= */ "Multiple audio presentations or assets not supported");
      }

      // We've already asserted audioPresentationsCount = 1.
      int activeExtensionSubstreamMask =
          headerBits.readBits(extensionSubstreamIndex + 1); // nuActiveExSSMask

      for (int i = 0; i < extensionSubstreamIndex + 1; i++) {
        if (((activeExtensionSubstreamMask >> i) & 0x1) == 1) {
          headerBits.skipBits(8); // nuActiveAssetMask
        }
      }

      enableMixMetadata = headerBits.readBit();
      if (enableMixMetadata) { // bMixMetadataEnbl
        headerBits.skipBits(2); // nuMixMetadataAdjLevel
        int mixerOutputMaskBits = (headerBits.readBits(2) + 1) << 2; // nuBits4MixOutMask
        int mixerOutputConfigurationCount = headerBits.readBits(2) + 1; // nuNumMixOutConfigs
        mixerOutChannels = new int[mixerOutputConfigurationCount];
        // Output Mixing Configuration Loop
        for (int i = 0; i < mixerOutputConfigurationCount; i++) {
          int mask = headerBits.readBits(mixerOutputMaskBits); // nuMixOutChMask
          mixerOutChannels[i] = getRemapChannelCount(mask);
        }
      }
    } else {
      // Assignments below are placeholders and will never be used as they are only relevant when
      // staticFieldsPresent == true. Initialised here to keep the compiler happy.
      referenceClockCode = C.INDEX_UNSET;
      extensionSubstreamFrameDurationCode = 0;
    }

    // We've already asserted assetsCount = 1.
    headerBits.skipBits(extensionSubstreamFrameSizeBits); // nuAssetFsize
    int sampleRate = C.RATE_UNSET_INT;
    int channelCount = C.LENGTH_UNSET; // nuTotalNumChs
    boolean embeddedStereo = false; // bEmbeddedStereoFlag
    boolean embedded6ch = false; // bEmbeddedSixChFlag

    // Asset descriptor: Size, Index and Per Stream Static Metadata, see ETSI TS 102 114 V1.6.1
    // (2019-08) Table 7-5.
    headerBits.skipBits(9 + 3); // nuAssetDescriptFsize, nuAssetIndex
    String mimeType = null;
    if (staticFieldsPresent) {
      if (headerBits.readBit()) { // bAssetTypeDescrPresent
        headerBits.skipBits(4); // nuAssetTypeDescriptor
      }
      if (headerBits.readBit()) { // bLanguageDescrPresent
        headerBits.skipBits(24); // LanguageDescriptor
      }
      if (headerBits.readBit()) { // bInfoTextPresent
        int infoTextByteSize = headerBits.readBits(10) + 1; // nuInfoTextByteSize
        headerBits.skipBytes(infoTextByteSize); // InfoTextString
      }
      headerBits.skipBits(5); // nuBitResolution
      sampleRate = SAMPLE_RATE_BY_INDEX[headerBits.readBits(4)]; // nuMaxSampleRate
      channelCount = headerBits.readBits(8) + 1;
      if (headerBits.readBit()) { // bOne2OneMapChannels2Speakers
        if (channelCount > 2) {
          embeddedStereo = headerBits.readBit(); // bEmbeddedStereoFlag
        }
        if (channelCount > 6) {
          embedded6ch = headerBits.readBit(); // bEmbeddedSixChFlag
        }
        int speakerMaskLength = 0;
        if (headerBits.readBit()) { // bSpkrMaskEnabled
          speakerMaskLength = (headerBits.readBits(2) + 1) << 2; // nuNumBits4SAMask
          headerBits.skipBits(speakerMaskLength); // nuSpkrActivityMask
        }
        int speakerRemapSetsCount = headerBits.readBits(3); // nuNumSpkrRemapSets
        int[] speakerRemapSets = new int[speakerRemapSetsCount];
        for (int i = 0; i < speakerRemapSetsCount; i++) {
          speakerRemapSets[i] = headerBits.readBits(speakerMaskLength); // nuStndrSpkrLayoutMask[ns]
        }
        for (int i = 0; i < speakerRemapSetsCount; i++) {
          int remapChannelCount = getRemapChannelCount(speakerRemapSets[i]);
          int remapMaskLength = headerBits.readBits(5) + 1; // nuNumDecCh4Remap[ns]
          for (int j = 0; j < remapChannelCount; j++) {
            int remapMask = headerBits.readBits(remapMaskLength); // nuRemapDecChMask[ns][nCh]
            int coef = Integer.bitCount(remapMask); // nCoef
            headerBits.skipBits(coef * 5); // nuSpkrRemapCodes[ns][nCh][nc]
          }
        }
      } else {
        headerBits.skipBits(3); // nuRepresentationType
      }

      parseAssetDescriptorDynamicData(
          headerBits,
          embeddedStereo,
          embedded6ch,
          channelCount,
          enableMixMetadata,
          mixerOutChannels);

      mimeType = parseDecoderNavigationData(headerBits);
    }
    // Done reading necessary bits, ignoring the rest.

    long frameDurationUs = C.TIME_UNSET;
    if (staticFieldsPresent) {
      int referenceClockFrequency;
      //  ETSI TS 102 114 V1.6.1 (2019-08) Table 7-3.
      switch (referenceClockCode) {
        case 0:
          referenceClockFrequency = 32_000;
          break;
        case 1:
          referenceClockFrequency = 44_100;
          break;
        case 2:
          referenceClockFrequency = 48_000;
          break;
        default:
          throw ParserException.createForMalformedContainer(
              /* message= */ "Unsupported reference clock code in DTS HD header: "
                  + referenceClockCode,
              /* cause= */ null);
      }
      frameDurationUs =
          Util.scaleLargeTimestamp(
              extensionSubstreamFrameDurationCode, C.MICROS_PER_SECOND, referenceClockFrequency);
    }
    return new DtsHeader(
        mimeType,
        channelCount,
        sampleRate,
        extensionSubstreamFrameSize,
        frameDurationUs,
        /* bitrate= */ 0,
        /* codecs= */ null);
  }

  // Asset descriptor: Dynamic Metadata - DRC, DNC and Mixing Metadata, see ETSI TS 102 114
  // V1.6.1 (2019-08) Table 7-6.
  private static void parseAssetDescriptorDynamicData(
      ParsableBitArray headerBits,
      boolean embeddedStereo,
      boolean embedded6ch,
      int channelCount,
      boolean enableMixMetadata,
      @Nullable int[] mixerOutChannels) {
    boolean hasDrcCoef = headerBits.readBit();
    if (hasDrcCoef) { // bDRCCoefPresent
      headerBits.skipBits(8); // nuDRCCode
    }
    if (headerBits.readBit()) { // bDialNormPresent
      headerBits.skipBits(5); // nuDialNormCode
    }
    if (hasDrcCoef && embeddedStereo) {
      headerBits.skipBits(8); // nuDRC2ChDmixCode
    }
    if (enableMixMetadata && headerBits.readBit()) { // bMixMetadataPresent
      checkNotNull(mixerOutChannels);
      headerBits.skipBits(1 + 6); // bExternalMixFlag, nuPostMixGainAdjCode
      if (headerBits.readBits(2) < 3) { // nuControlMixerDRC
        headerBits.skipBits(3); // nuLimit4EmbeddedDRC
      } else {
        headerBits.skipBits(8); // nuCustomDRCCode
      }
      boolean audioScalePerChannel = headerBits.readBit(); // bEnblPerChMainAudioScale
      for (int mixerOutChannel : mixerOutChannels) {
        if (audioScalePerChannel) {
          headerBits.skipBits(6 * mixerOutChannel); // nuMainAudioScaleCode[ns][nCh]
        } else {
          headerBits.skipBits(6); // nuMainAudioScaleCode[ns][0]
        }
      }
      int mixesCount = 1; // nEmDM
      int[] channelCountsForDownmixes = new int[3];
      channelCountsForDownmixes[0] = channelCount; // nDecCh[0]
      if (embedded6ch) {
        channelCountsForDownmixes[mixesCount] = 6; // nDecCh[nEmDM]
        mixesCount++; // nEmDM
      }
      if (embeddedStereo) {
        channelCountsForDownmixes[mixesCount] = 2; // nDecCh[nEmDM]
        mixesCount++; // nEmDM
      }
      for (int mixerOutChannel : mixerOutChannels) {
        for (int downmix = 0; downmix < mixesCount; downmix++) {
          int channelCountForDownmix = channelCountsForDownmixes[downmix];
          for (int downmixChannel = 0; downmixChannel < channelCountForDownmix; downmixChannel++) {
            int mask = headerBits.readBits(mixerOutChannel); // nuMixMapMask[ns][nE][nCh]
            int coefficients = Integer.bitCount(mask); // nuNumMixCoefs[ns][nE][nCh]
            headerBits.skipBits(coefficients * 6); // nuMixCoeffs[ns][nE][nCh][nC]
          }
        }
      }
    }
  }

  // Asset descriptor: Decoder Navigation Data, see ETSI TS 102 114 V1.6.1 (2019-08) Table 7-7.
  private static String parseDecoderNavigationData(ParsableBitArray headerBits)
      throws ParserException {
    int codingMode = headerBits.readBits(2); // nuCodingMode
    switch (codingMode) {
      case 0: // DTS-HD Coding Mode that may contain multiple coding components
        int extensionMask = headerBits.readBits(12);
        if ((extensionMask & 0x100) != 0) { // Low bit rate component
          return MimeTypes.AUDIO_DTS_EXPRESS;
        } else if ((extensionMask & 0x200) != 0) { // Lossless extension
          if ((extensionMask & 0x001) != 0) { // Core component within the core substream
            return MimeTypes.AUDIO_DTS_HD_MA;
          } else {
            return MimeTypes.AUDIO_MEDIA3_DTS_HD_MA_CORELESS;
          }
        } else {
          return MimeTypes.AUDIO_DTS_HD;
        }
      case 1: // DTS-HD Loss-less coding mode without CBR component
        return MimeTypes.AUDIO_MEDIA3_DTS_HD_MA_CORELESS;
      case 2: // DTS-HD Low bit-rate mode
        return MimeTypes.AUDIO_DTS_EXPRESS;
      case 3: // The auxiliary coding mode is reserved for future applications.
      default:
        throw ParserException.createForMalformedContainer(
            /* message= */ "Unsupported coding mode in DTS HD header: " + codingMode,
            /* cause= */ null);
    }
  }

  // See Table 7-10 in ETSI TS 102 114 V1.6.1
  private static int getRemapChannelCount(int mask) {
    int remapChannelCount = 0;
    if ((mask & 0x0001) != 0) { // Centre in front of listener
      remapChannelCount += 1;
    }
    if ((mask & 0x0002) != 0) { // Left/Right in front
      remapChannelCount += 2;
    }
    if ((mask & 0x0004) != 0) { // Left/Right surround on side in rear
      remapChannelCount += 2;
    }
    if ((mask & 0x0008) != 0) { // Low frequency effects subwoofer
      remapChannelCount += 1;
    }
    if ((mask & 0x0010) != 0) { // Centre surround in rear
      remapChannelCount += 1;
    }
    if ((mask & 0x0020) != 0) { // Left/Right height in front
      remapChannelCount += 2;
    }
    if ((mask & 0x0040) != 0) { // Left/Right surround in rear
      remapChannelCount += 2;
    }
    if ((mask & 0x0080) != 0) { // Centre Height in front
      remapChannelCount += 1;
    }
    if ((mask & 0x0100) != 0) { // Over the listener's head
      remapChannelCount += 1;
    }
    if ((mask & 0x0200) != 0) { // Between left/right and centre in front
      remapChannelCount += 2;
    }
    if ((mask & 0x0400) != 0) { // Left/Right on side in front
      remapChannelCount += 2;
    }
    if ((mask & 0x0800) != 0) { // Left/Right surround on side
      remapChannelCount += 2;
    }
    if ((mask & 0x1000) != 0) { // Second low frequency effects subwoofer
      remapChannelCount += 1;
    }
    if ((mask & 0x2000) != 0) { // Left/Right height on side
      remapChannelCount += 2;
    }
    if ((mask & 0x4000) != 0) { // Centre height in rear
      remapChannelCount += 1;
    }
    if ((mask & 0x8000) != 0) { // Left/Right height in rear
      remapChannelCount += 2;
    }
    return remapChannelCount;
  }

  /**
   * Returns the size of the extension substream header in a DTS-HD frame according to ETSI TS 102
   * 114 V1.6.1 (2019-08), Section 7.5.2.
   *
   * @param headerPrefix A byte array containing at least the first 55 bits of a DTS-HD frame.
   * @return Size of the DTS-HD frame header in bytes.
   */
  public static int parseDtsHdHeaderSize(byte[] headerPrefix) {
    ParsableBitArray headerPrefixBits = getNormalizedFrame(headerPrefix);
    headerPrefixBits.skipBits(32 + 8 + 2); // SYNCEXTSSH, UserDefinedBits, nExtSSIndex
    // Unpack the num of bits to be used to read header size
    int headerBits = headerPrefixBits.readBit() ? 12 : 8; // bHeaderSizeType
    // Unpack the substream header size
    return headerPrefixBits.readBits(headerBits) + 1; // nuExtSSHeaderSize
  }

  /**
   * Parses the {@link DtsHeader} data from the headers of a DTS-UHD(Profile 2) frame according to
   * ETSI TS 103 491 V1.2.1 (2019-05), Section 6.4.3.
   *
   * @param header The DTS-UHD header to parse.
   * @param uhdAudioChunkId An {@link AtomicInteger} containing the last read UHD audio chunk ID
   *     from a synchronized frame, or zero if unset. This parameter is both an input and output
   *     parameter. In synchronized frames, the input value is not used; instead, the parameter is
   *     set to the current UHD audio chunk ID, which becomes the output value. For non-synchronized
   *     frames, it is used without any modification.
   * @return The {@link DtsHeader} data extracted from the header.
   */
  public static DtsHeader parseDtsUhdHeader(byte[] header, AtomicInteger uhdAudioChunkId)
      throws ParserException {
    ParsableBitArray headerBits = getNormalizedFrame(header);
    int syncWord = headerBits.readBits(32);
    boolean syncFrameFlag = syncWord == SYNC_VALUE_UHD_FTOC_SYNC_BE;

    int ftocPayloadInBytes =
        parseUnsignedVarInt(
                headerBits, UHD_FTOC_PAYLOAD_LENGTH_TABLE, /* extractAndAddFlag= */ true)
            + 1;

    // ETSI TS 103 491 V1.2.1, Section 6.4.5.
    int sampleRate = C.RATE_UNSET_INT; // m_unAudioSamplRate
    long frameDurationUs = C.TIME_UNSET;
    if (syncFrameFlag) {
      // ETSI TS 103 491 V1.2.1, Section 6.4.6.1.
      if (!headerBits.readBit()) { // m_bFullChannelBasedMixFlag
        throw ParserException.createForUnsupportedContainerFeature(
            /* message= */ "Only supports full channel mask-based audio presentation");
      }

      // ETSI TS 103 491 V1.2.1, Section 6.4.6.2.
      checkCrc(header, ftocPayloadInBytes);

      int baseDurationIndex = headerBits.readBits(2);
      int baseDuration; // m_unBaseDuration
      // ETSI TS 103 491 V1.2.1 (2019-05) Table 6-13.
      switch (baseDurationIndex) {
        case 0:
          baseDuration = 512;
          break;
        case 1:
          baseDuration = 480;
          break;
        case 2:
          baseDuration = 384;
          break;
        default:
          throw ParserException.createForMalformedContainer(
              /* message= */ "Unsupported base duration index in DTS UHD header: "
                  + baseDurationIndex,
              /* cause= */ null);
      }
      int frameDurationInClockPeriods =
          baseDuration * (headerBits.readBits(3) + 1); // m_unFrameDuration
      int clockRateIndex = headerBits.readBits(2);
      int clockRateHertz; // m_unClockRateInHz
      switch (clockRateIndex) {
        case 0:
          clockRateHertz = 32_000;
          break;
        case 1:
          clockRateHertz = 44_100;
          break;
        case 2:
          clockRateHertz = 48_000;
          break;
        default:
          throw ParserException.createForMalformedContainer(
              /* message= */ "Unsupported clock rate index in DTS UHD header: " + clockRateIndex,
              /* cause= */ null);
      }
      // Skip time stamp information if present, see section 5.2.3.2.
      if (headerBits.readBit()) { // m_bParamPresent
        // m_bUpdateFlag == true as m_bSyncFramePredefValueExists is set to false in the encoder.
        headerBits.skipBits(32 + 4); // m_TimeStamp
      }
      int sampleRateMultiplier = (1 << headerBits.readBits(2));
      sampleRate = clockRateHertz * sampleRateMultiplier;
      frameDurationUs =
          Util.scaleLargeTimestamp(
              frameDurationInClockPeriods, C.MICROS_PER_SECOND, clockRateHertz);
    }

    // ETSI TS 103 491 V1.2.1, Table 6-20.
    // m_bFullChannelBasedMixFlag == true as we throw unsupported container feature otherwise.
    int chunkPayloadBytes = 0;
    int numOfMetadataChunks = syncFrameFlag ? 1 : 0; // Metadata chunks
    for (int i = 0; i < numOfMetadataChunks; i++) {
      int metadataChunkSize =
          parseUnsignedVarInt(
              headerBits, UHD_METADATA_CHUNK_SIZE_LENGTH_TABLE, /* extractAndAddFlag= */ true);
      chunkPayloadBytes += metadataChunkSize;
    }

    // See ETSI TS 103 491 V1.2.1, Section 6.4.14.4.
    // m_bFullChannelBasedMixFlag == true as we throw unsupported container feature otherwise.
    int numAudioChunks = 1;
    for (int i = 0; i < numAudioChunks; i++) {
      // If syncFrameFlag is true the audio chunk ID will be present.
      if (syncFrameFlag) {
        uhdAudioChunkId.set(
            parseUnsignedVarInt(
                headerBits, UHD_AUDIO_CHUNK_ID_LENGTH_TABLE, /* extractAndAddFlag= */ true));
      }
      int audioChunkSize =
          uhdAudioChunkId.get() != 0
              ? parseUnsignedVarInt(
                  headerBits, UHD_AUDIO_CHUNK_SIZE_LENGTH_TABLE, /* extractAndAddFlag= */ true)
              : 0;
      chunkPayloadBytes += audioChunkSize;
    }

    int frameSize = ftocPayloadInBytes + chunkPayloadBytes;
    return new DtsHeader(
        MimeTypes.AUDIO_DTS_UHD_P2,
        // To determine the actual number of channels from a bit stream, we need to read the
        // metadata chunk bytes. If defining a constant channel count causes problems, we can
        // consider adding additional parsing logic for UHD frames.
        // For now, using the estimated number of channels for DTS UHD bitstreams as 2.
        /* channelCount= */ 2,
        sampleRate,
        frameSize,
        frameDurationUs,
        /* bitrate= */ 0,
        /* codecs= */ null);
  }

  /**
   * Returns the size of frame header in a DTS-UHD(Profile 2) frame according to ETSI TS 103 491
   * V1.2.1 (2019-05), Section 6.4.3.
   *
   * @param headerPrefix A byte array containing at least the first 47 bits of a DTS-UHD frame.
   * @return Size of the DTS-UHD frame header in bytes.
   */
  public static int parseDtsUhdHeaderSize(byte[] headerPrefix) {
    ParsableBitArray headerPrefixBits = getNormalizedFrame(headerPrefix);
    headerPrefixBits.skipBits(32); // SYNC
    return parseUnsignedVarInt(
            headerPrefixBits, UHD_HEADER_SIZE_LENGTH_TABLE, /* extractAndAddFlag= */ true)
        + 1;
  }

  /**
   * Returns a {@link Format} with an adjusted MIME type if the sample data at the current {@link
   * ExtractorInput} is a DTS-HD sample with static fields, or the unmodified {@code format} if it
   * is not.
   *
   * @param input The {@link ExtractorInput} to read from.
   * @param sampleSize The size of the sample data.
   * @param format The {@link Format} to build upon.
   * @return The updated {@link Format}.
   * @throws IOException If an error occurs reading from the input.
   */
  public static Format updateFormatWithDtsHdInfo(
      ExtractorInput input, int sampleSize, Format format) throws IOException {
    ParsableByteArray sampleData = new ParsableByteArray(sampleSize);
    if (!input.peekFully(
        sampleData.getData(), /* offset= */ 0, sampleSize, /* allowEndOfInput= */ true)) {
      return format;
    }
    input.resetPeekPosition();
    int word = sampleData.peekInt();
    // Skip the core frame if present (it doesn't have to be).
    if (DtsUtil.getFrameType(word) == DtsUtil.FRAME_TYPE_CORE) {
      if (sampleData.bytesLeft() < 10) {
        return format;
      }
      byte[] header = new byte[10];
      sampleData.readBytes(header, /* offset= */ 0, /* length= */ 10);
      int frameSize = DtsUtil.getDtsFrameSize(header);
      if (frameSize <= 0 || sampleData.limit() < frameSize + 4) {
        return format;
      }
      sampleData.setPosition(frameSize);
      word = sampleData.peekInt();
    }
    if (DtsUtil.getFrameType(word) != DtsUtil.FRAME_TYPE_EXTENSION_SUBSTREAM) {
      return format;
    }
    if (sampleData.bytesLeft() < 7) {
      return format;
    }
    int extHeaderOffset = sampleData.getPosition();
    byte[] headerPrefix = new byte[7];
    sampleData.readBytes(headerPrefix, /* offset= */ 0, /* length= */ 7);
    sampleData.setPosition(extHeaderOffset);
    int frameSize = parseDtsHdHeaderSize(headerPrefix);
    if (frameSize <= 0 || sampleData.bytesLeft() < frameSize) {
      return format;
    }
    byte[] header = new byte[frameSize];
    sampleData.readBytes(header, /* offset= */ 0, /* length= */ frameSize);
    DtsHeader dtsHeader = parseDtsHdHeader(header);
    // If the MIME type was parsed successfully, use it. If it is null (e.g. because static
    // fields were missing), there's nothing we can do other than assume it is DTS-HD.
    String mimeType = dtsHeader.mimeType != null ? dtsHeader.mimeType : MimeTypes.AUDIO_DTS_HD;
    @Nullable String codecs = dtsHeader.codecs;
    if (codecs == null && isDtsHdMaAudioMimeType(mimeType)) {
      int payloadOffset = sampleData.getPosition();
      int payloadLength =
          Math.min(
              sampleData.bytesLeft(),
              Math.min(Math.max(0, dtsHeader.frameSize - frameSize), XLL_X_SCAN_MAX_BYTES));
      codecs = getDtsXCodecs(sampleData.getData(), payloadOffset, payloadLength);
    }
    if (Objects.equals(format.sampleMimeType, mimeType)
        && (codecs == null || Objects.equals(format.codecs, codecs))) {
      return format;
    }
    Format.Builder builder = format.buildUpon().setSampleMimeType(mimeType);
    if (codecs != null) {
      builder.setCodecs(codecs);
    }
    return builder.build();
  }

  /**
   * Check if calculated and extracted CRC-16 words match. See ETSI TS 103 491 V1.2.1, Table 6-8.
   */
  private static void checkCrc(byte[] frame, int sizeInBytes) throws ParserException {
    int initialValue = 0xFFFF;
    int extractedCrc =
        (((frame[sizeInBytes - 2] << 8) & initialValue) | (frame[sizeInBytes - 1] & 0xFF));
    int calculatedCrc = Util.crc16(frame, /* start= */ 0, /* end= */ sizeInBytes - 2, initialValue);
    if (extractedCrc != calculatedCrc) {
      throw ParserException.createForMalformedContainer(
          /* message= */ "CRC check failed", /* cause= */ null);
    }
  }

  /**
   * Helper function for the DTS UHD header parsing. Used to extract a field of variable length. See
   * ETSI TS 103 491 V1.2.1, Section 5.2.3.1.
   */
  private static int parseUnsignedVarInt(
      ParsableBitArray frameBits, int[] lengths, boolean extractAndAddFlag) {
    int index = 0;
    for (int i = 0; i < 3; i++) {
      if (frameBits.readBit()) {
        index++;
      } else {
        break;
      }
    }

    int value = 0;
    if (extractAndAddFlag) {
      for (int i = 0; i < index; i++) {
        value += (1 << lengths[i]);
      }
    }
    return value + frameBits.readBits(lengths[index]);
  }

  private static ParsableBitArray getNormalizedFrame(byte[] frame) {
    if (frame[0] == FIRST_BYTE_BE
        || frame[0] == FIRST_BYTE_EXTSS_BE
        || frame[0] == FIRST_BYTE_UHD_FTOC_SYNC_BE
        || frame[0] == FIRST_BYTE_UHD_FTOC_NONSYNC_BE) {
      // The frame is already 16-bit mode, big endian.
      return new ParsableBitArray(frame);
    }
    // Data is not normalized, but we don't want to modify frame.
    frame = Arrays.copyOf(frame, frame.length);
    if (isLittleEndianFrameHeader(frame)) {
      // Change endianness.
      for (int i = 0; i < frame.length - 1; i += 2) {
        byte temp = frame[i];
        frame[i] = frame[i + 1];
        frame[i + 1] = temp;
      }
    }
    ParsableBitArray frameBits = new ParsableBitArray(frame);
    if (frame[0] == (byte) (SYNC_VALUE_14B_BE >> 24)) {
      // Discard the 2 most significant bits of each 16 bit word.
      ParsableBitArray scratchBits = new ParsableBitArray(frame);
      while (scratchBits.bitsLeft() >= 16) {
        scratchBits.skipBits(2);
        frameBits.putInt(scratchBits.readBits(14), 14);
      }
    }
    frameBits.reset(frame);
    return frameBits;
  }

  private static boolean isLittleEndianFrameHeader(byte[] frameHeader) {
    return frameHeader[0] == FIRST_BYTE_LE
        || frameHeader[0] == FIRST_BYTE_14B_LE
        || frameHeader[0] == FIRST_BYTE_EXTSS_LE
        || frameHeader[0] == FIRST_BYTE_UHD_FTOC_SYNC_LE
        || frameHeader[0] == FIRST_BYTE_UHD_FTOC_NONSYNC_LE;
  }

  public static int readSyncWord(byte[] data) {
    return ((data[0] & 0xFF) << 24)
        | ((data[1] & 0xFF) << 16)
        | ((data[2] & 0xFF) << 8)
        | (data[3] & 0xFF);
  }

  public static int parseDtsHdFrameSize(byte[] header) {
    ParsableBitArray bits = getNormalizedFrame(header);
    bits.skipBits(32 + 8 + 2);
    boolean longHeader = bits.readBit();
    bits.skipBits(longHeader ? 12 : 8);
    return bits.readBits(longHeader ? 20 : 16) + 1;
  }

  public static boolean isRiffContainer(ExtractorInput input) throws IOException {
    byte[] header = new byte[4];
    input.peekFully(header, 0, 4);
    input.resetPeekPosition();
    return header[0] == 0x52 && header[1] == 0x49 && header[2] == 0x46 && header[3] == 0x46;
  }

  public static int findDtsCoreSync(ExtractorInput input, int maxBytesToSearch) throws IOException {
    byte[] scratch = new byte[4];
    input.peekFully(scratch, 0, 2);
    int bytesSniffed = 2;
    maxBytesToSearch -= 2;
    while (maxBytesToSearch >= 2) {
      input.peekFully(scratch, 2, 2);
      bytesSniffed += 2;
      maxBytesToSearch -= 2;
      int word = readSyncWord(scratch);
      if (getFrameType(word) == FRAME_TYPE_CORE) {
        return bytesSniffed - 4;
      }
      scratch[0] = scratch[2];
      scratch[1] = scratch[3];
    }
    return -1;
  }

  private DtsUtil() {}
}
