/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.ts;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.min;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.ParserException;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.extractor.DtsUtil;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.extractor.ts.TsPayloadReader.TrackIdGenerator;
import com.google.common.primitives.Ints;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;

/** Parses a continuous DTS or DTS UHD byte stream and extracts individual samples. */
@UnstableApi
public final class DtsReader implements ElementaryStreamReader {

  private static final int STATE_FINDING_SYNC = 0;
  private static final int STATE_READING_CORE_HEADER = 1;
  private static final int STATE_FINDING_EXTSS_HEADER_SIZE = 2;
  private static final int STATE_READING_EXTSS_HEADER = 3;
  private static final int STATE_FINDING_UHD_HEADER_SIZE = 4;
  private static final int STATE_READING_UHD_HEADER = 5;
  private static final int STATE_READING_SAMPLE = 6;
  private static final int STATE_CHECKING_FOR_EXTSS_AFTER_CORE = 7;

  /** Size of core header, in bytes. */
  private static final int CORE_HEADER_SIZE = 18;

  /**
   * Maximum possible size of extension sub-stream header, in bytes. See ETSI TS 102 114 V1.6.1
   * (2019-08) Section 7.5.2.
   */
  /* package */ static final int EXTSS_HEADER_SIZE_MAX = 4096;

  /**
   * Maximum size of DTS UHD(DTS:X) frame header, in bytes. See ETSI TS 103 491 V1.2.1 (2019-05)
   * Section 6.4.4.3.
   */
  /* package */ static final int FTOC_MAX_HEADER_SIZE = 5408;

  private final ParsableByteArray headerScratchBytes;

  /** The chunk ID is read in synchronized frames and re-used in non-synchronized frames. */
  private final AtomicInteger uhdAudioChunkId;

  @Nullable private final String language;
  private final @C.RoleFlags int roleFlags;
  private final String containerMimeType;

  private @MonotonicNonNull String formatId;
  private @MonotonicNonNull TrackOutput output;

  private int state;
  private int bytesRead;
  private int extSyncBytes;

  /** Used to find the header. */
  private int syncBytes;

  // Used when parsing the header.
  private long sampleDurationUs;
  private @MonotonicNonNull Format format;
  private int sampleSize;
  private int coreSampleSize;
  private @DtsUtil.FrameType int frameType;
  private int extensionSubstreamHeaderSize;
  private int uhdHeaderSize;

  // Used when reading the samples.
  private boolean coreFormatPendingEmit;
  private long timeUs;
  private long pendingTimeUs;
  private boolean hasCore;
  private boolean skipExtssUntilCore;
  private int dtsXScanWord;
  private int dtsXScanBytesRemaining;

  /**
   * Constructs a new reader for DTS elementary streams.
   *
   * @param language Track language.
   * @param roleFlags Track role flags.
   * @param maxHeaderSize Maximum size of the header in a frame.
   * @param containerMimeType The MIME type of the container holding the stream.
   */
  public DtsReader(
      @Nullable String language,
      @C.RoleFlags int roleFlags,
      int maxHeaderSize,
      String containerMimeType) {
    headerScratchBytes = new ParsableByteArray(new byte[maxHeaderSize]);
    state = STATE_FINDING_SYNC;
    timeUs = C.TIME_UNSET;
    pendingTimeUs = C.TIME_UNSET;
    uhdAudioChunkId = new AtomicInteger();
    extensionSubstreamHeaderSize = C.LENGTH_UNSET;
    uhdHeaderSize = C.LENGTH_UNSET;
    this.language = language;
    this.roleFlags = roleFlags;
    this.containerMimeType = containerMimeType;
  }

  @Override
  public void seek() {
    state = STATE_FINDING_SYNC;
    bytesRead = 0;
    syncBytes = 0;
    extSyncBytes = 0;
    coreSampleSize = 0;
    timeUs = C.TIME_UNSET;
    pendingTimeUs = C.TIME_UNSET;
    uhdAudioChunkId.set(0);
    coreFormatPendingEmit = false;
    skipExtssUntilCore = hasCore;
    dtsXScanWord = 0;
    dtsXScanBytesRemaining = 0;
  }

  @Override
  public void createTracks(ExtractorOutput extractorOutput, TrackIdGenerator idGenerator) {
    idGenerator.generateNewId();
    formatId = idGenerator.getFormatId();
    output = extractorOutput.track(idGenerator.getTrackId(), C.TRACK_TYPE_AUDIO);
  }

  @Override
  public void packetStarted(long pesTimeUs, @TsPayloadReader.Flags int flags) {
    if (pesTimeUs != C.TIME_UNSET) {
      if (state != STATE_FINDING_SYNC) {
        pendingTimeUs = pesTimeUs;
      } else {
        timeUs = pesTimeUs;
        pendingTimeUs = C.TIME_UNSET;
      }
    }
  }

  @Override
  public void consume(ParsableByteArray data) throws ParserException {
    // Asserts that createTracks has been called.
    checkNotNull(output);
    while (data.bytesLeft() > 0) {
      switch (state) {
        case STATE_FINDING_SYNC:
          if (skipToNextSyncWord(data)) {
            if (skipExtssUntilCore && frameType == DtsUtil.FRAME_TYPE_EXTENSION_SUBSTREAM) {
              bytesRead = 0;
            } else {
              if (frameType == DtsUtil.FRAME_TYPE_CORE) {
                skipExtssUntilCore = false;
              }
              if (frameType == DtsUtil.FRAME_TYPE_UHD_SYNC
                  || frameType == DtsUtil.FRAME_TYPE_UHD_NON_SYNC) {
                state = STATE_FINDING_UHD_HEADER_SIZE;
              } else if (frameType == DtsUtil.FRAME_TYPE_CORE) {
                state = STATE_READING_CORE_HEADER;
              } else {
                state = STATE_FINDING_EXTSS_HEADER_SIZE;
              }
            }
          }
          break;
        case STATE_READING_CORE_HEADER:
          if (continueRead(data, headerScratchBytes.getData(), CORE_HEADER_SIZE)) {
            parseCoreHeader();
            headerScratchBytes.setPosition(0);
            output.sampleData(headerScratchBytes, CORE_HEADER_SIZE);
            state = STATE_READING_SAMPLE;
          }
          break;
        case STATE_FINDING_EXTSS_HEADER_SIZE:
          // Read enough bytes to parse the header size information.
          if (continueRead(data, headerScratchBytes.getData(), /* targetLength= */ 7)) {
            extensionSubstreamHeaderSize =
                DtsUtil.parseDtsHdHeaderSize(headerScratchBytes.getData());
            state = STATE_READING_EXTSS_HEADER;
          }
          break;
        case STATE_READING_EXTSS_HEADER:
          if (continueRead(data, headerScratchBytes.getData(), extensionSubstreamHeaderSize)) {
            parseExtensionSubstreamHeader();
            headerScratchBytes.setPosition(0);
            output.sampleData(headerScratchBytes, extensionSubstreamHeaderSize);
            state = STATE_READING_SAMPLE;
          }
          break;
        case STATE_FINDING_UHD_HEADER_SIZE:
          // Read enough bytes to parse the header size information.
          if (continueRead(data, headerScratchBytes.getData(), /* targetLength= */ 6)) {
            uhdHeaderSize = DtsUtil.parseDtsUhdHeaderSize(headerScratchBytes.getData());
            // Adjust the array read position if data read is more than the actual header size.
            if (bytesRead > uhdHeaderSize) {
              int extraBytes = bytesRead - uhdHeaderSize;
              bytesRead -= extraBytes;
              data.setPosition(data.getPosition() - extraBytes);
            }
            state = STATE_READING_UHD_HEADER;
          }
          break;
        case STATE_READING_UHD_HEADER:
          if (continueRead(data, headerScratchBytes.getData(), uhdHeaderSize)) {
            parseUhdHeader();
            headerScratchBytes.setPosition(0);
            output.sampleData(headerScratchBytes, uhdHeaderSize);
            state = STATE_READING_SAMPLE;
          }
          break;
        case STATE_READING_SAMPLE:
          int bytesToRead = min(data.bytesLeft(), sampleSize - bytesRead);
          maybeScanDtsX(data.getData(), data.getPosition(), bytesToRead);
          output.sampleData(data, bytesToRead);
          bytesRead += bytesToRead;
          if (bytesRead == sampleSize) {
            if (frameType == DtsUtil.FRAME_TYPE_CORE) {
              coreSampleSize = sampleSize;
              bytesRead = 0;
              extSyncBytes = 0;
              state = STATE_CHECKING_FOR_EXTSS_AFTER_CORE;
            } else {
              // packetStarted method must be called before consuming samples.
              checkState(timeUs != C.TIME_UNSET);
              int combinedSize =
                  sampleSize
                      + (frameType == DtsUtil.FRAME_TYPE_EXTENSION_SUBSTREAM ? coreSampleSize : 0);
              long emittedTimeUs = timeUs;
              output.sampleMetadata(
                  timeUs,
                  frameType == DtsUtil.FRAME_TYPE_UHD_NON_SYNC ? 0 : C.BUFFER_FLAG_KEY_FRAME,
                  combinedSize,
                  0,
                  null);
              timeUs += sampleDurationUs;
              if (pendingTimeUs != C.TIME_UNSET) {
                if (pendingTimeUs != emittedTimeUs) {
                  timeUs = pendingTimeUs;
                }
                pendingTimeUs = C.TIME_UNSET;
              }
              coreSampleSize = 0;
              state = STATE_FINDING_SYNC;
            }
          }
          break;
        case STATE_CHECKING_FOR_EXTSS_AFTER_CORE:
          while (data.bytesLeft() > 0 && bytesRead < 4) {
            extSyncBytes <<= 8;
            extSyncBytes |= data.readUnsignedByte();
            bytesRead++;
          }
          if (bytesRead == 4) {
            if (DtsUtil.getFrameType(extSyncBytes) == DtsUtil.FRAME_TYPE_EXTENSION_SUBSTREAM) {
              setHeaderScratchBytesFromSyncWord(extSyncBytes);
              frameType = DtsUtil.FRAME_TYPE_EXTENSION_SUBSTREAM;
              extSyncBytes = 0;
              state = STATE_FINDING_EXTSS_HEADER_SIZE;
            } else {
              if (coreFormatPendingEmit) {
                output.format(checkNotNull(format));
                coreFormatPendingEmit = false;
              }
              checkState(timeUs != C.TIME_UNSET);
              long emittedTimeUs = timeUs;
              output.sampleMetadata(timeUs, C.BUFFER_FLAG_KEY_FRAME, coreSampleSize, 0, null);
              timeUs += sampleDurationUs;
              if (pendingTimeUs != C.TIME_UNSET) {
                if (pendingTimeUs != emittedTimeUs) {
                  timeUs = pendingTimeUs;
                }
                pendingTimeUs = C.TIME_UNSET;
              }
              coreSampleSize = 0;

              syncBytes = extSyncBytes;
              extSyncBytes = 0;
              frameType = DtsUtil.getFrameType(syncBytes);
              if (frameType == DtsUtil.FRAME_TYPE_UHD_SYNC
                  || frameType == DtsUtil.FRAME_TYPE_UHD_NON_SYNC) {
                setHeaderScratchBytesFromSyncWord(syncBytes);
                syncBytes = 0;
                state = STATE_FINDING_UHD_HEADER_SIZE;
              } else if (frameType == DtsUtil.FRAME_TYPE_CORE) {
                setHeaderScratchBytesFromSyncWord(syncBytes);
                syncBytes = 0;
                state = STATE_READING_CORE_HEADER;
              } else {
                bytesRead = 0;
                state = STATE_FINDING_SYNC;
              }
            }
          }
          break;
        default:
          throw new IllegalStateException();
      }
    }
  }

  @Override
  public void endOfInputReached() {
    if (state == STATE_CHECKING_FOR_EXTSS_AFTER_CORE) {
      checkNotNull(output);
      if (coreFormatPendingEmit) {
        output.format(checkNotNull(format));
        coreFormatPendingEmit = false;
      }
      if (timeUs != C.TIME_UNSET) {
        output.sampleMetadata(timeUs, C.BUFFER_FLAG_KEY_FRAME, coreSampleSize, 0, null);
        timeUs += sampleDurationUs;
      }
      coreSampleSize = 0;
      bytesRead = 0;
      syncBytes = 0;
      extSyncBytes = 0;
      state = STATE_FINDING_SYNC;
    }
  }

  /**
   * Sets the {@link TrackOutput} to receive DTS samples, along with a format ID.
   *
   * <p>This is an alternative to {@link #createTracks(ExtractorOutput, TrackIdGenerator)}, for use
   * when the track output is managed externally (e.g. by {@link
   * androidx.media3.extractor.wav.WavExtractor}).
   *
   * @param trackOutput The track output to receive samples.
   * @param formatId The format identifier.
   */
  public void setTrackOutput(TrackOutput trackOutput, String formatId) {
    this.formatId = formatId;
    this.output = trackOutput;
  }

  /**
   * Continues a read from the provided {@code source} into a given {@code target}. It's assumed
   * that the data should be written into {@code target} starting from an offset of zero.
   *
   * @param source The source from which to read.
   * @param target The target into which data is to be read.
   * @param targetLength The target length of the read.
   * @return Whether the target length was reached.
   */
  private boolean continueRead(ParsableByteArray source, byte[] target, int targetLength) {
    int bytesToRead = min(source.bytesLeft(), targetLength - bytesRead);
    source.readBytes(target, bytesRead, bytesToRead);
    bytesRead += bytesToRead;
    return bytesRead == targetLength;
  }

  /**
   * Locates the next SYNC word value in the buffer, advancing the position to the byte that
   * immediately follows it. If SYNC was not located, the position is advanced to the limit.
   *
   * @param pesBuffer The buffer whose position should be advanced.
   * @return Whether SYNC word was found.
   */
  private boolean skipToNextSyncWord(ParsableByteArray pesBuffer) {
    while (pesBuffer.bytesLeft() > 0) {
      syncBytes <<= 8;
      syncBytes |= pesBuffer.readUnsignedByte();
      frameType = DtsUtil.getFrameType(syncBytes);
      if (frameType != DtsUtil.FRAME_TYPE_UNKNOWN) {
        setHeaderScratchBytesFromSyncWord(syncBytes);
        syncBytes = 0;
        return true;
      }
    }
    return false;
  }

  private void setHeaderScratchBytesFromSyncWord(int syncWord) {
    byte[] headerData = headerScratchBytes.getData();
    headerData[0] = (byte) ((syncWord >> 24) & 0xFF);
    headerData[1] = (byte) ((syncWord >> 16) & 0xFF);
    headerData[2] = (byte) ((syncWord >> 8) & 0xFF);
    headerData[3] = (byte) (syncWord & 0xFF);
    bytesRead = 4;
  }

  /** Parses the DTS Core Sub-stream header. */
  @RequiresNonNull("output")
  private void parseCoreHeader() {
    hasCore = true;
    byte[] frameData = headerScratchBytes.getData();
    if (format == null) {
      format =
          DtsUtil.parseDtsFormat(frameData, formatId, language, roleFlags, containerMimeType, null);
      coreFormatPendingEmit = true;
    }
    sampleSize = DtsUtil.getDtsFrameSize(frameData);
    // In this class a sample is an access unit (frame in DTS), but the format's sample rate
    // specifies the number of PCM audio samples per second.
    sampleDurationUs =
        Ints.checkedCast(
            Util.sampleCountToDurationUs(
                DtsUtil.parseDtsAudioSampleCount(frameData), format.sampleRate));
  }

  /** Parses the DTS Extension Sub-stream header. */
  @RequiresNonNull("output")
  private void parseExtensionSubstreamHeader() throws ParserException {
    DtsUtil.DtsHeader dtsHeader = DtsUtil.parseDtsHdHeader(headerScratchBytes.getData());
    updateFormatWithDtsHeaderInfo(dtsHeader);
    sampleSize = dtsHeader.frameSize;
    startDtsXScan(dtsHeader);
    if (dtsHeader.frameDurationUs != C.TIME_UNSET) {
      sampleDurationUs = dtsHeader.frameDurationUs;
    }
  }

  /** Parses the UHD frame header. */
  @RequiresNonNull({"output"})
  private void parseUhdHeader() throws ParserException {
    DtsUtil.DtsHeader dtsHeader =
        DtsUtil.parseDtsUhdHeader(headerScratchBytes.getData(), uhdAudioChunkId);
    // Format updates will happen only in FTOC sync frames.
    if (frameType == DtsUtil.FRAME_TYPE_UHD_SYNC) {
      updateFormatWithDtsHeaderInfo(dtsHeader);
    }
    sampleSize = dtsHeader.frameSize;
    sampleDurationUs = dtsHeader.frameDurationUs == C.TIME_UNSET ? 0 : dtsHeader.frameDurationUs;
  }

  @RequiresNonNull({"output"})
  private void updateFormatWithDtsHeaderInfo(DtsUtil.DtsHeader dtsHeader) {
    if (dtsHeader.sampleRate == C.RATE_UNSET_INT || dtsHeader.channelCount == C.LENGTH_UNSET) {
      return;
    }
    String sampleMimeType =
        dtsHeader.mimeType != null
            ? dtsHeader.mimeType
            : format != null ? format.sampleMimeType : null;
    @Nullable String codecs = dtsHeader.codecs;
    if (codecs == null && format != null && Objects.equals(sampleMimeType, format.sampleMimeType)) {
      codecs = format.codecs;
    }
    if (format == null
        || coreFormatPendingEmit
        || dtsHeader.channelCount != format.channelCount
        || dtsHeader.sampleRate != format.sampleRate
        || !Objects.equals(sampleMimeType, format.sampleMimeType)
        || !Objects.equals(codecs, format.codecs)) {
      Format.Builder formatBuilder = format == null ? new Format.Builder() : format.buildUpon();
      format =
          formatBuilder
              .setId(formatId)
              .setContainerMimeType(containerMimeType)
              .setSampleMimeType(sampleMimeType)
              .setCodecs(codecs)
              .setChannelCount(dtsHeader.channelCount)
              .setSampleRate(dtsHeader.sampleRate)
              .setLanguage(language)
              .setRoleFlags(roleFlags)
              .build();
      output.format(format);
      coreFormatPendingEmit = false;
    }
  }

  private void startDtsXScan(DtsUtil.DtsHeader dtsHeader) {
    dtsXScanWord = 0;
    dtsXScanBytesRemaining =
        DtsUtil.isDtsHdMaAudioMimeType(dtsHeader.mimeType)
            ? min(
                Math.max(0, sampleSize - extensionSubstreamHeaderSize),
                DtsUtil.XLL_X_SCAN_MAX_BYTES)
            : 0;
  }

  @RequiresNonNull({"output"})
  private void maybeScanDtsX(byte[] data, int offset, int length) {
    int bytesToScan = min(length, dtsXScanBytesRemaining);
    for (int i = 0; i < bytesToScan; i++) {
      dtsXScanWord = (dtsXScanWord << 8) | (data[offset + i] & 0xFF);
      @Nullable String codecs = DtsUtil.getDtsXCodecs(dtsXScanWord);
      if (codecs != null) {
        updateFormatCodecs(codecs);
        dtsXScanBytesRemaining = 0;
        dtsXScanWord = 0;
        return;
      }
    }
    dtsXScanBytesRemaining -= bytesToScan;
    if (dtsXScanBytesRemaining == 0) {
      dtsXScanWord = 0;
    }
  }

  @RequiresNonNull({"output"})
  private void updateFormatCodecs(String codecs) {
    if (format != null && !Objects.equals(format.codecs, codecs)) {
      format = format.buildUpon().setCodecs(codecs).build();
      output.format(format);
      coreFormatPendingEmit = false;
    }
  }
}
